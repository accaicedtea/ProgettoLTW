<?php 
    
?>
<body>
   <table>
      <thead>
         <tr>
            <th>Data</th>
            <th>Categoria</th>
            <th>Descrizione</th>
            <th>Importo</th>
            <th>Tipo</th>
         </tr>
      </thead>
      <tbody id="demo">
         <!-- Prodcuts from javascript file in here. -->
      </tbody>
   </table>
 
   <script src="test.js"></script> <!-- Link to the javascript file -->
